from __future__ import annotations

from typing import Dict, List, Tuple

from langchain_core.messages import SystemMessage, HumanMessage

from ..schemas import EvidenceItem, State, Task
from ..llm import llm


WORKER_SYSTEM = """You are a section-writing agent.

Write ONE blog section in Markdown.
- Start with: ## <Section Title>
- Follow with 2-6 short paragraphs and/or bullet lists as appropriate.
- If include_code=true, include a small code snippet.
- If requires_citations=true, cite only from the provided Evidence URLs (inline as (URL) or [n] style).
- Do NOT invent citations. If a needed citation is missing, explicitly say: 'Not found in provided sources.'
"""


def _evidence_block(evidence: List[EvidenceItem]) -> str:
    lines = []
    for i, e in enumerate(evidence[:15], start=1):
        date_s = f" | {e.published_at}" if e.published_at else ""
        lines.append(f"[{i}] {e.title}{date_s} - {e.url}")
    return "\n".join(lines)


def worker_node(task: Task, state: State) -> Dict:
    evidence = state.get("evidence") or []
    ev = _evidence_block(evidence) if evidence else "None"

    prompt = f"""Section title: {task.title}
Goal: {task.goal}
Bullets:
- """ + "\n- ".join(task.bullets) + f"""

Target words: {task.target_words}
requires_citations={task.requires_citations}
include_code={task.include_code}

Evidence:
{ev}
"""

    msg = [SystemMessage(content=WORKER_SYSTEM), HumanMessage(content=prompt)]
    resp = llm.invoke(msg)
    return {"sections": [(task.id, resp.content)]}

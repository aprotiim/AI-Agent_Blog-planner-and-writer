from __future__ import annotations

from typing import Dict

from langchain_core.messages import SystemMessage, HumanMessage

from ..schemas import Plan, State
from ..llm import llm


PLANNER_SYSTEM = """You are a senior technical editor.
Create a blog plan as JSON matching this schema:

Plan = {
  "blog_title": str,
  "audience": str,
  "tone": str,
  "blog_kind": "explainer" | "tutorial" | "news_roundup" | "comparison" | "system_design",
  "constraints": [str],
  "tasks": [
    {
      "id": int,
      "title": str,
      "goal": str,
      "bullets": [str]  # 3-6,
      "target_words": int,  # 120-550
      "tags": [str],
      "requires_research": bool,
      "requires_citations": bool,
      "include_code": bool
    }
  ]
}

Rules:
- Produce 5-9 tasks.
- Each task must be specific and lead to a section starting with '## <title>'.
- If evidence exists, set requires_citations=true for tasks with factual claims.
"""


def orchestrator_node(state: State) -> Dict:
    topic = state["topic"]
    mode = state.get("mode", "hybrid")
    evidence = state.get("evidence") or []
    ev_summary = "\n".join([f"- {e.title} ({e.url})" for e in evidence][:12])

    msg = [
        SystemMessage(content=PLANNER_SYSTEM),
        HumanMessage(content=f"Topic: {topic}\nMode: {mode}\nEvidence (may be empty):\n{ev_summary}\nReturn only valid JSON.")
    ]
    resp = llm.invoke(msg)
    plan = Plan.model_validate_json(resp.content)
    return {"plan": plan}

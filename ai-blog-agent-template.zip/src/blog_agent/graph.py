from __future__ import annotations

from datetime import date
from typing import Dict

from langgraph.graph import StateGraph, START, END
from langgraph.types import Send

from .schemas import State
from .nodes.router import route_node
from .nodes.research import research_node
from .nodes.orchestrator import orchestrator_node
from .nodes.worker import worker_node
from .nodes.reducer import merge_node, decide_images_node, generate_and_place_images_node


def _fanout_workers(state: State):
    plan = state.get("plan")
    if not plan:
        return []
    sends = []
    for task in plan.tasks:
        sends.append(Send("worker", {"task": task, "state": state}))
    return sends


def _worker_adapter(inputs: Dict) -> Dict:
    # inputs contains {"task": Task, "state": State}
    return worker_node(inputs["task"], inputs["state"])


def build_graph():
    g = StateGraph(State)

    g.add_node("router", route_node)
    g.add_node("research", research_node)
    g.add_node("orchestrator", orchestrator_node)
    g.add_node("worker", _worker_adapter)
    g.add_node("merge", merge_node)
    g.add_node("decide_images", decide_images_node)
    g.add_node("generate_images", generate_and_place_images_node)

    g.add_edge(START, "router")

    def _route_after_router(state: State):
        return "research" if state.get("needs_research") else "orchestrator"

    g.add_conditional_edges("router", _route_after_router, {"research": "research", "orchestrator": "orchestrator"})
    g.add_edge("research", "orchestrator")

    # fanout
    g.add_conditional_edges("orchestrator", _fanout_workers, {"worker": "worker"})
    g.add_edge("worker", "merge")

    g.add_edge("merge", "decide_images")
    g.add_edge("decide_images", "generate_images")
    g.add_edge("generate_images", END)

    return g.compile()


# Export compiled app for UI
app = build_graph()

from __future__ import annotations

import json
from datetime import date
from pathlib import Path
from typing import Any, Dict, List

import streamlit as st

from blog_agent.graph import app
from blog_agent.utils.io import list_saved_blogs, read_markdown, outputs_paths
from blog_agent.config import IMAGES_DIR, BLOGS_DIR
from blog_agent.utils.markdown import rewrite_image_paths


st.set_page_config(page_title="AI Blog Agent", layout="wide")
st.title("📝 AI Agent Blog Planner & Writer")

with st.sidebar:
    st.header("Input")
    topic = st.text_area("Topic", value="Explain RAG vs Agentic RAG with a comparison table.", height=120)
    as_of = st.date_input("As-of date", value=date.today())
    recency_days = st.number_input("Open-book max age (days)", min_value=7, max_value=365, value=120)
    run_btn = st.button("🚀 Generate Blog")

    st.divider()
    st.header("Saved blogs")
    saved = list_saved_blogs()
    selected = st.selectbox("Open a saved blog", options=[None] + saved, format_func=lambda p: "—" if p is None else p.name)

state_out: Dict[str, Any] | None = None
logs: List[str] = []

def _invoke_agent() -> Dict[str, Any]:
    init = {
        "topic": topic.strip(),
        "mode": "hybrid",
        "needs_research": False,
        "queries": [],
        "evidence": [],
        "plan": None,
        "as_of": str(as_of),
        "recency_days": int(recency_days),
        "sections": [],
        "merged_md": "",
        "md_with_placeholders": "",
        "image_specs": [],
        "final": "",
    }
    # Use streaming events so we can show logs
    final_state = None
    for ev in app.stream(init):
        logs.append(str(ev))
        if isinstance(ev, dict):
            final_state = ev
    return final_state or init

if run_btn and topic.strip():
    with st.spinner("Generating..."):
        state_out = _invoke_agent()

if selected is not None and state_out is None:
    md = read_markdown(selected)
    state_out = {"final": md, "plan": None, "evidence": [], "image_specs": [], "merged_md": md}

if state_out:
    tabs = st.tabs(["Plan", "Evidence", "Markdown Preview", "Images", "Logs"])

    with tabs[0]:
        plan = state_out.get("plan")
        if plan:
            st.subheader(plan.get("blog_title", "Plan"))
            st.write({"audience": plan.get("audience"), "tone": plan.get("tone"), "kind": plan.get("blog_kind")})
            tasks = plan.get("tasks", [])
            st.dataframe(tasks, use_container_width=True)
        else:
            st.info("No plan object found in state (open a saved blog or generate a new one).")

    with tabs[1]:
        evidence = state_out.get("evidence") or []
        if evidence:
            st.dataframe([e if isinstance(e, dict) else getattr(e, "model_dump", lambda: e)() for e in evidence], use_container_width=True)
        else:
            st.info("No evidence collected (either closed-book route or Tavily key missing).")

    with tabs[2]:
        md = state_out.get("final", "")
        md = rewrite_image_paths(md, IMAGES_DIR)
        st.markdown(md)

        st.download_button("Download Markdown", data=md.encode("utf-8"), file_name="blog.md", mime="text/markdown")

    with tabs[3]:
        img_files = sorted(IMAGES_DIR.glob("*"))
        if not img_files:
            st.info("No images found.")
        else:
            for p in img_files:
                st.image(str(p), caption=p.name, use_container_width=True)

    with tabs[4]:
        st.code("\n\n".join(logs[-200:]) if logs else "No logs.")
else:
    st.caption("Enter a topic and click Generate, or open a saved blog from the sidebar.")

def test_smoke_imports():
    from blog_agent.graph import app
    assert app is not None
